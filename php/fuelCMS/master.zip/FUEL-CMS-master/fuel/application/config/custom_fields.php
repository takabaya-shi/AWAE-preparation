<?php 
/*
|--------------------------------------------------------------------------
| Form builder 
|--------------------------------------------------------------------------
|
| Specify field types and other Form_builder configuration properties
| This file is included by the fuel/modules/fuel/config/form_builder.php file
*/
$fields['my_custom_field'] = array();

include(FUEL_PATH.'config/custom_fields.php');

/* End of file form_builder.php */
/* Location: ./application/config/form_builder.php */