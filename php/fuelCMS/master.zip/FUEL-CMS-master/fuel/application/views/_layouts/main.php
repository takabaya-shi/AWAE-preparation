<?php $this->load->view('_blocks/header')?>
	
	<section id="main_inner">
		<?php echo fuel_var('body', 'This is a default layout. To change this layout go to the fuel/application/views/_layouts/main.php file.'); ?>
	</section>
	
<?php $this->load->view('_blocks/footer')?>
