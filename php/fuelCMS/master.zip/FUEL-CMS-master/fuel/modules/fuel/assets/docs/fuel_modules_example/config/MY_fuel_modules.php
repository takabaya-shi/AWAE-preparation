<?php 
/*
|--------------------------------------------------------------------------
| MY Custom Modules
|--------------------------------------------------------------------------
|
| Specifies the module controller (key) and the name (value) for fuel
*/

$config['modules']['authors'] = array();
$config['modules']['articles'] = array();
$config['modules']['categories'] = array();
