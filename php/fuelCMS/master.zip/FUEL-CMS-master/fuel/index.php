<?php
header('Location: start');
exit();