print "Script is running..."
